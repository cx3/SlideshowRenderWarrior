elasticdeform
=============

Deformation
-----------

.. autofunction:: elasticdeform.deform_random_grid
.. autofunction:: elasticdeform.deform_grid


Gradient
--------

.. autofunction:: elasticdeform.deform_grid_gradient
