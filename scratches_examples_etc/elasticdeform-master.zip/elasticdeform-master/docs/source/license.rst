License
=======

.. include:: ../../LICENSE.txt
