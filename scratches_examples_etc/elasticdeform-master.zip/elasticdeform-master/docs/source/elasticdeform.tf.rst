elasticdeform.tf
================

TensorFlow wrapper function
---------------------------

.. autofunction:: elasticdeform.tf.deform_grid
