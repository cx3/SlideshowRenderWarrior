# image-warp
warp image using python + opencv3

I implemented this code to study facial image warp based on imgwarp-js project(https://github.com/cxcxcxcx/imgwarp-js)
And used OpenFace project(https://github.com/TadasBaltrusaitis/OpenFace) to detect landamark coordinate

![alt tag](https://github.com/kimsup10/image-warp/blob/master/result.jpg?raw=true)
You can see that the left eye of warped_image become larger than one of original_image

No input interface, just place test image on project folder and deal with input image file name and points list in warp_test.py
